#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
python3 QA_TESTS/run_qa.py
