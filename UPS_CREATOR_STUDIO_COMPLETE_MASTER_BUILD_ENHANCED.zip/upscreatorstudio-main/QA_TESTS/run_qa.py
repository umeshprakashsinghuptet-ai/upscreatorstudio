#!/usr/bin/env python3
"""Offline release checks for UPS Creator Studio. No network or DB writes."""
from pathlib import Path
from html.parser import HTMLParser
from collections import Counter
import re, subprocess, sys, zipfile
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def record(name, ok, detail=''):
    checks.append((name, bool(ok), detail))
class Markup(HTMLParser):
    def __init__(self): super().__init__(); self.ids=[]; self.refs=[]
    def handle_starttag(self, tag, attrs):
        d=dict(attrs)
        if d.get('id'): self.ids.append(d['id'])
        for key in ('src','href'):
            v=d.get(key,'').strip()
            if v and not v.startswith(('http://','https://','mailto:','tel:','#','data:','javascript:')):
                self.refs.append(v.split('#')[0].split('?')[0])
for f in ('app.js','config.js'):
    p=ROOT/f
    if p.exists():
        r=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
        record(f+' Node syntax',r.returncode==0,(r.stderr or r.stdout).strip()[:500])
    else: record(f+' exists',False,'missing')
app=(ROOT/'app.js').read_text(encoding='utf-8')
config=(ROOT/'config.js').read_text(encoding='utf-8')
# Registry IDs: read the literal id declarations inside each registry section.
mod=app.split('const CORE_MODULES = [',1)[1].split('/* 2. MODULE COUNT VALIDATION */',1)[0] + app.split('CORE_MODULES.push(',1)[1].split('/* 2. MODULE COUNT VALIDATION */',1)[0].split(');',1)[0]
mod_ids=[int(x) for x in re.findall(r'\bid\s*:\s*(\d+)',mod)]
record('Core module registry 1..100',sorted(set(mod_ids))==list(range(1,101)),f'{len(mod_ids)} matched declarations; {len(set(mod_ids))} unique IDs')
lock=app.split('const WORKFLOW_LOCKS = [',1)[1].split('/* 2. VALIDATE LOCK COUNT */',1)[0] + app.split('WORKFLOW_LOCKS.push(',1)[1].split('/* 2. VALIDATE LOCK COUNT */',1)[0].split(');',1)[0]
lock_ids=[int(x) for x in re.findall(r'\bid\s*:\s*(\d+)',lock)]
record('Workflow locks 1..25',sorted(set(lock_ids))==list(range(1,26)),f'{len(lock_ids)} matched declarations; {len(set(lock_ids))} unique IDs')
eng=app.split('const UPS_PRODUCTION_ENGINES = [',1)[1].split('const UPS_PODCAST_ENGINES',1)[0]
stg=app.split('const UPS_WORKFLOW_STAGES = [',1)[1].split('window.UPS_SYSTEM_ARCHITECTURE',1)[0]
pod=app.split('const UPS_PODCAST_ENGINES = [',1)[1].split('const UPS_WORKFLOW_STAGES',1)[0]
record('Production engines = 12',len(re.findall(r'^\s*\["',eng,re.M))==12,str(len(re.findall(r'^\s*\["',eng,re.M))))
record('Workflow stages = 15',len(re.findall(r'"[^"]+"',stg.split('].map',1)[0]))==15,str(len(re.findall(r'"[^"]+"',stg.split('].map',1)[0]))))
record('Podcast specialized engines = 16',len(re.findall(r'^\s*\["',pod,re.M))==16,str(len(re.findall(r'^\s*\["',pod,re.M))))
for f in ('index.html',):
    p=ROOT/f
    if not p.exists(): record(f+' exists',False,'missing'); continue
    h=Markup(); h.feed(p.read_text(encoding='utf-8'))
    dup=[k for k,v in Counter(h.ids).items() if v>1]
    missing=[v for v in h.refs if v and not (ROOT/v).exists()]
    record(f+' duplicate HTML IDs',not dup,str(dup[:10]) if dup else f'{len(h.ids)} IDs; none duplicated')
    record(f+' local asset references',not missing,str(missing[:10]) if missing else 'all local references exist')

# Auto-Pilot flow and single-entry checks
flow=app.split('const WIZARD_QUESTIONS = [',1)[1].split('/* 2. FILTER ACTIVE QUESTIONS */',1)[0]
flow_ids=re.findall(r'id:\s*["\']([^"\']+)["\']',flow)
expected_flow=['purpose','mode','output','activity','platform','audience','language','category','subcategory','topic','creativeDirection','visualStyle','identityRules','voiceStyle','textRules','brandCTA','purposeDetail','dialogue','duration','aspectRatio']
record('Auto-Pilot question order',flow_ids==expected_flow,str(flow_ids))
record('Manual specific topic required','question.id === "topic" || !question.optional' in app and 'Specific Topic देना जरूरी है' in app,'manual topic validation')
record('Freeform command prompt field','id: "creativeDirection"' in flow and 'type: "textarea"' in flow,'up to 6,000 characters')
record('Per-clip prompt builder and 900-character cap','function buildUPSClipPrompt' in app and 'prompt.length <= 900' in app and 'downloadAllClipPrompts' in app,'each generated clip prompt capped at 900 characters')
record('Clipboard fallback support','document.execCommand(\'copy\')' in app and 'navigator.clipboard.writeText' in app,'modern and fallback copy paths')
record('Per-clip copy/download controls','data-copy-clip' in app and 'data-download-clip' in app,'clip-level actions')
record('100-module manifest in production JSON','core_module_manifest: CORE_MODULES.map' in app,'full module registry included in JSON package')
record('25-lock summary count','${passed}/${WORKFLOW_LOCKS.length}' in app,'dynamic 25-lock summary')
record('Workflow lock gate before generation','runCompleteLockAudit(APP_STATE.wizard.brief || {})' in app,'brief audit runs before prompt generation')
record('Sidebar quick search','id="upsSidebarSearch"' in (ROOT/'index.html').read_text(encoding='utf-8') and 'GLOBAL QUICK SEARCH' in app,'menu and studio search')
record('Premium footer links and responsive styling','footer-links' in (ROOT/'index.html').read_text(encoding='utf-8') and '.footer-inner' in (ROOT/'styles.css').read_text(encoding='utf-8'),'responsive footer')
record('Searchable category and topic taxonomy','type: "search-select"' in flow and 'type: "topic-search"' in flow and 'wizardTopicOptions' in app,'category > subcategory > topic search')
regional=(ROOT/'regional-topic-bank.js').read_text(encoding='utf-8')
record('Regional topic bank wired into Auto-Pilot','getRegionalTopicIdeas' in app and 'getRegionalTopicIdeas' in regional,'India/USA regional topic ideas are available to topic search and AUTO rotation')
record('Regional topic bank includes 1,000 ideas per region',regional.count('—') >= 2000 and 'India' in regional and 'USA' in regional,'20 domains × 10 themes × 5 angles = 1,000 ideas per region')
node_bank=subprocess.run(['node','QA_TESTS/test_topic_bank.mjs'],cwd=ROOT,capture_output=True,text=True)
record('Regional topic bank data integrity',node_bank.returncode==0,(node_bank.stdout or node_bank.stderr).strip())
record('Topic history is region/category scoped','ups_topic_history_${region}_${category}' in app,'separate no-repeat history per region and category')
record('Single HTML entry point',len(list(ROOT.glob('*.html')))==1,[p.name for p in ROOT.glob('*.html')].__str__())
record('Embedded GYAN APEX launcher','UPS_GYAN_APEX_EMBEDDED_HTML' in app and 'data-open-gyan-apex' in app,'embedded in app.js')
record('Package access popup and prompt guard','function requirePackageAccess' in app and 'requirePackageAccess("prompt_generation")' in app,'client-side UX gate; server enforcement pending')

css=(ROOT/'styles.css').read_text(encoding='utf-8')
record('Unified premium dark palette','--ui-bg:#080d19' in css and '--ui-surface:#111a2c' in css and 'SINGLE SOURCE OF COLOUR TRUTH' in css,'one midnight-navy palette across public and workspace UI')
record('Readable theme contrast tokens','--text:#f4f7ff' in css and '--muted:#b2bfd4' in css and 'input,select,textarea' in css,'high-contrast text and dark form surfaces')
record('Keyboard focus visibility',':focus-visible' in css,'visible keyboard focus ring')
record('Reduced motion support','prefers-reduced-motion:reduce' in css,'reduced-motion accessibility')
record('CSS brace balance',css.count('{')==css.count('}'),f"{css.count('{')} open / {css.count('}')} close")
for f in ('index.html','styles.css','app.js','config.js','README_HINDI.txt','QA_REPORT.txt','PROJECT_REQUIREMENTS_MASTER_HINDI.md','AUTOPILOT_FLOW_AND_PACKAGE_RULES_HINDI.md','SUPABASE_SECURITY_HARDENING.sql','regional-topic-bank.js','REGIONAL_TOPIC_BANK_GUIDE_HINDI.md','QA_TESTS/test_topic_bank.mjs'):
    record('Required file '+f,(ROOT/f).is_file(), 'present' if (ROOT/f).is_file() else 'missing')
lines=['UPS CREATOR STUDIO — OFFLINE QA RESULTS','',f'Project folder: {ROOT.name}','Checks: '+str(len(checks)), 'PASS: '+str(sum(x[1] for x in checks)), 'FAIL: '+str(sum(not x[1] for x in checks)),'']
for n,ok,d in checks: lines.append(('PASS' if ok else 'FAIL')+' | '+n+' | '+d)
lines += ['', 'LIVE / EXTERNAL TESTS: NOT PERFORMED','- Supabase Auth, database, RLS, Storage and two-user isolation','- Admin server-side authorization and payment approval','- GitHub Pages deployment and Actions','- Gemini/provider generation and MP4 rendering','- Android Chrome and desktop interactive end-to-end testing','', 'No destructive Supabase operation is performed by this test.']
(ROOT/'QA_TESTS'/'QA_RESULTS.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('\n'.join(lines))
if any(not x[1] for x in checks): sys.exit(1)
