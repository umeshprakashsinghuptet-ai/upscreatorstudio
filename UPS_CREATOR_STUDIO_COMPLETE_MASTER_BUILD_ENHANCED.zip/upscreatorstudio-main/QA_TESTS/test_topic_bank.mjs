import { REGIONAL_TOPIC_BANK } from '../regional-topic-bank.js';
let failed = false;
for (const region of ['India', 'USA']) {
  const domains = REGIONAL_TOPIC_BANK[region] || {};
  const topics = Object.values(domains).flat();
  const unique = new Set(topics);
  const ok = Object.keys(domains).length === 20 && topics.length === 1000 && unique.size === 1000;
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${region} topic bank | ${Object.keys(domains).length} domains; ${topics.length} topics; ${unique.size} unique`);
  if (!ok) failed = true;
}
if (failed) process.exit(1);
