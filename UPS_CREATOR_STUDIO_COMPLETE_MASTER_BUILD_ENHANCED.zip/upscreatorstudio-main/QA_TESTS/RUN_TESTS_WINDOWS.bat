@echo off
cd /d "%~dp0.."
python QA_TESTS\run_qa.py
pause
